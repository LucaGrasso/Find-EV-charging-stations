package lucagrasso.clientcolonnine;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.RequestQueue;

import android.net.Uri;

public class ListActivity extends AppCompatActivity {

    private ArrayAdapter<String> arrayAdapter;

    private String TAG = "ListActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        final ListView lv = (ListView) findViewById(R.id.lv);

        String latitudine = getIntent().getStringExtra("latitudine");
        String longitudine = getIntent().getStringExtra("longitudine");
        String minpowerkw = getIntent().getStringExtra("minpowerkw");

        String url = "https://lumbar-check.glitch.me/trova-colonnine/?";
        url = url + "latitude=" + latitudine + "&";
        url = url + "longitude=" + longitudine + "&";
        url = url + "minpowerkw=" + minpowerkw;

        Log.i(TAG, "latitudine arrivata:" + latitudine);
        Log.i(TAG, "latitudine arrivata:" + longitudine);
        Log.i(TAG, "latitudine arrivata:" + minpowerkw);

        final ArrayList<String> colonnine = new ArrayList<String>();
        final ArrayList<Colonnina> colonnineList = new ArrayList<Colonnina>();

        arrayAdapter = new ArrayAdapter<String>
                (this, R.layout.list_item, colonnine);

        lv.setAdapter(arrayAdapter);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {

                    @Override
                    public void onResponse(JSONArray response) {
                        //Toast.makeText(getApplicationContext(), response.length(), Toast.LENGTH_LONG).show();
                        try {
                            Log.i(TAG, "risposta: " + response.length());
                            //parseColonnine(colonnine, response);
                            parseColonnine(colonnineList, response);
                            Log.i(TAG, "stringa creata: " + colonnine.get(0));
                            arrayAdapter.notifyDataSetChanged();
                        } catch(Exception ex) {
                            Log.i(TAG, ex.getMessage() + ex.toString());
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i(TAG, "errore" + error.getMessage() + error.toString());

                    }
                });

        MyApplication.getInstance().addToRequestQueue(jsonObjectRequest, MyApplication.TAG);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


            }
        });

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                int index = colonnine.get(position).indexOf(',');
                int colonninaID = Integer.parseInt(colonnine.get(position).substring(4, index));
                Intent intent = new Intent(getBaseContext(), AddCommentActivity.class);
                intent.putExtra("id", colonninaID);
                startActivity(intent);
                return true;
            }
        });

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Uri gmmIntentUri = Uri.parse("google.navigation:q=45,7");

                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);

                mapIntent.setPackage("com.google.android.apps.maps");

                startActivity(mapIntent);
            }
        });
    }

    private void parseColonnineString(ArrayList<String> colonnine, JSONArray arrayColonnine) throws JSONException {

        JSONObject colObject = null;
        for(int i=0; i<arrayColonnine.length(); i++){
            colObject = arrayColonnine.getJSONObject(i);
            String s = "ID: " + colObject.get("id") + ", Latitudine: " + colObject.get("Latitude") + ", Longitudine: " + colObject.get("Longitude") + ", Distanza: " + colObject.get("distance");
            colonnine.add(s);
        }

    }

    private void parseColonnine(ArrayList<Colonnina> colonnine, JSONArray arrayColonnine) throws JSONException {

        JSONObject colObject = null;
        for(int i=0; i<arrayColonnine.length(); i++){
            colObject = arrayColonnine.getJSONObject(i);
            Colonnina col = new Colonnina();

            col.setDistanza(colObject.get("distance").toString());
            col.setLatitudine(colObject.get("Latitude").toString());
            col.setLongitudine(colObject.get("Longitude").toString());
            col.setId(colObject.get("id").toString());

            colonnine.add(col);
        }

    }
}
